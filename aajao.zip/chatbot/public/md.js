"use strict";
// Small, safe Markdown renderer. Builds DOM nodes with textContent only (never innerHTML),
// so model output can never inject HTML or scripts.
(function () {
  const el = (tag, cls) => { const n = document.createElement(tag); if (cls) n.className = cls; return n; };

  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); return true; }
    catch {
      const ta = document.createElement("textarea");
      ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      let ok = false; try { ok = document.execCommand("copy"); } catch { /* ignore */ }
      ta.remove(); return ok;
    }
  }

  const INLINE = /`([^`\n]+)`|\*\*(.+?)\*\*|~~(.+?)~~|\*(?!\s)(.+?)(?<!\s)\*|\b_(?!\s)(.+?)(?<!\s)_\b|\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)|(https?:\/\/[^\s<]+[^\s<.,;:!?)\]])/g;

  function inline(text, parent) {
    INLINE.lastIndex = 0;
    let last = 0, m;
    const re = new RegExp(INLINE.source, "g");
    while ((m = re.exec(text))) {
      if (m.index > last) parent.appendChild(document.createTextNode(text.slice(last, m.index)));
      let n;
      if (m[1] !== undefined) { n = el("code"); n.textContent = m[1]; }
      else if (m[2] !== undefined) { n = el("strong"); inline(m[2], n); }
      else if (m[3] !== undefined) { n = el("del"); inline(m[3], n); }
      else if (m[4] !== undefined) { n = el("em"); inline(m[4], n); }
      else if (m[5] !== undefined) { n = el("em"); inline(m[5], n); }
      else if (m[6] !== undefined) { n = linkEl(m[7], m[6]); }
      else { n = linkEl(m[8], m[8]); }
      parent.appendChild(n);
      last = m.index + m[0].length;
    }
    if (last < text.length) parent.appendChild(document.createTextNode(text.slice(last)));
  }

  function linkEl(href, label) {
    const a = el("a"); a.textContent = label;
    if (/^https?:\/\//i.test(href)) { a.href = href; a.target = "_blank"; a.rel = "noopener noreferrer nofollow"; }
    return a;
  }

  function codeBlock(code, lang) {
    const wrap = el("div", "codeblock");
    const head = el("div", "codehead");
    const label = el("span"); label.textContent = lang || "code";
    const btn = el("button", "act"); btn.type = "button"; btn.textContent = "Copy code";
    btn.addEventListener("click", async () => {
      const ok = await copyText(code);
      btn.textContent = ok ? "Copied" : "Copy failed";
      setTimeout(() => (btn.textContent = "Copy code"), 1500);
    });
    head.append(label, btn);
    const pre = el("pre"); const c = el("code"); c.textContent = code; pre.appendChild(c);
    wrap.append(head, pre);
    return wrap;
  }

  const LI = /^(\s*)([-*+]|\d{1,9}[.)])\s+(.*)$/;
  const SEP = /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/;
  const splitRow = (line) => {
    let s = line.trim();
    if (s.startsWith("|")) s = s.slice(1);
    if (s.endsWith("|") && !s.endsWith("\\|")) s = s.slice(0, -1);
    return s.split(/(?<!\\)\|/).map((c) => c.trim().replace(/\\\|/g, "|"));
  };

  function parseList(lines, i, parent) {
    const first = lines[i].match(LI);
    const baseIndent = first[1].length;
    const ordered = /\d/.test(first[2]);
    const list = el(ordered ? "ol" : "ul");
    if (ordered) { const st = parseInt(first[2], 10); if (st !== 1) list.start = st; }
    let lastLi = null;
    while (i < lines.length) {
      let m = lines[i].match(LI);
      if (!m) {
        // blank line(s) between items: keep going only if another item of this list follows
        if (/^\s*$/.test(lines[i])) {
          let j = i; while (j < lines.length && /^\s*$/.test(lines[j])) j++;
          const nm = j < lines.length && lines[j].match(LI);
          if (nm && nm[1].length >= baseIndent) { i = j; continue; }
          break;
        }
        // continuation line of the current item (indented, not a new block)
        if (lastLi && /^\s{2,}\S/.test(lines[i])) {
          lastLi.appendChild(el("br")); inline(lines[i].trim(), lastLi); i++; continue;
        }
        break;
      }
      if (m[1].length < baseIndent) break;
      if (m[1].length > baseIndent + 1 && lastLi) { i = parseList(lines, i, lastLi); continue; }
      if (/\d/.test(m[2]) !== ordered) break;
      lastLi = el("li"); inline(m[3], lastLi); list.appendChild(lastLi); i++;
    }
    parent.appendChild(list);
    return i;
  }

  function render(src, root) {
    root.textContent = "";
    const lines = String(src).replace(/\r\n?/g, "\n").split("\n");
    const para = [];
    const flush = () => {
      if (!para.length) return;
      const p = el("p");
      para.forEach((l, k) => { if (k) p.appendChild(el("br")); inline(l, p); });
      root.appendChild(p); para.length = 0;
    };
    let i = 0, m;
    while (i < lines.length) {
      const line = lines[i];
      if ((m = line.match(/^\s*(```+|~~~+)\s*([\w+#.-]*)/))) {
        flush();
        const fence = m[1], lang = m[2], buf = [];
        const closer = new RegExp("^\\s*" + (fence[0] === "`" ? "`" : "~") + "{" + fence.length + ",}\\s*$");
        i++;
        while (i < lines.length && !closer.test(lines[i])) { buf.push(lines[i]); i++; }
        i++; // skip closing fence (or run off the end while still streaming)
        root.appendChild(codeBlock(buf.join("\n"), lang));
        continue;
      }
      if (/^\s*$/.test(line)) { flush(); i++; continue; }
      if ((m = line.match(/^(#{1,6})\s+(.*?)\s*#*\s*$/))) {
        flush(); const h = el("h" + m[1].length); inline(m[2], h); root.appendChild(h); i++; continue;
      }
      if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(line)) { flush(); root.appendChild(el("hr")); i++; continue; }
      if (/^\s*>/.test(line)) {
        flush(); const q = [];
        while (i < lines.length && /^\s*>/.test(lines[i])) { q.push(lines[i].replace(/^\s*> ?/, "")); i++; }
        const bq = el("blockquote"); render(q.join("\n"), bq); root.appendChild(bq); continue;
      }
      if (line.includes("|") && i + 1 < lines.length && SEP.test(lines[i + 1]) && lines[i + 1].includes("-")) {
        flush();
        const head = splitRow(line);
        const wrap = el("div", "tablewrap"); const table = el("table");
        const thead = el("thead"); const hr = el("tr");
        head.forEach((c) => { const th = el("th"); inline(c, th); hr.appendChild(th); });
        thead.appendChild(hr); table.appendChild(thead);
        const tbody = el("tbody"); i += 2;
        while (i < lines.length && lines[i].includes("|") && !/^\s*$/.test(lines[i])) {
          const tr = el("tr");
          const cells = splitRow(lines[i]);
          for (let k = 0; k < head.length; k++) { const td = el("td"); inline(cells[k] || "", td); tr.appendChild(td); }
          tbody.appendChild(tr); i++;
        }
        table.appendChild(tbody); wrap.appendChild(table); root.appendChild(wrap);
        continue;
      }
      if (LI.test(line)) { flush(); i = parseList(lines, i, root); continue; }
      para.push(line); i++;
    }
    flush();
  }

  window.MD = { render, copyText };
})();
