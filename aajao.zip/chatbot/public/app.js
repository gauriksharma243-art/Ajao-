"use strict";
(function () {
  const $ = (id) => document.getElementById(id);
  const state = {
    me: null, features: { images: false, pdf: false, text: true }, convs: [], currentId: null,
    messages: [], busy: false, controller: null, pending: [], stick: true, shareUrl: "", lastCode: null,
    mode: "default", webSearch: false, compose: null,
  };
  let cfg = { modes: { default: null }, search: {}, image: {}, video: {}, features: {} };
  const MODE_NAMES = { default: "Default", fast: "Fast", reasoning: "Reasoning", smart: "Smart" };
  const NOT_CONF = "Not configured. Ask the owner to connect it.";

  // ------------------------------------------------------------------ theme (applied immediately to avoid a flash)
  function applyTheme(t) {
    if (!["system", "light", "dark"].includes(t)) t = "system";
    document.documentElement.dataset.theme = t;
    try { localStorage.setItem("aajao-theme", t); } catch { /* ignore */ }
    const dark = t === "dark" || (t === "system" && matchMedia("(prefers-color-scheme: dark)").matches);
    document.querySelector('meta[name="theme-color"]').content = dark ? "#17171a" : "#fafaf8";
    document.querySelectorAll("#theme-seg .seg-btn").forEach((b) => b.classList.toggle("active", b.dataset.theme === t));
  }
  try { applyTheme(localStorage.getItem("aajao-theme") || "system"); } catch { applyTheme("system"); }

  // ------------------------------------------------------------------ small helpers
  async function api(method, url, body) {
    const res = await fetch(url, {
      method, credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-Requested-With": "aajao" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    let data = {};
    try { data = await res.json(); } catch { /* ignore */ }
    if (res.status === 401 && state.me) { state.me = null; showAuth(); }
    if (!res.ok) throw new Error(data.error || "Something went wrong. Please try again.");
    return data;
  }
  let toastTimer;
  function toast(msg) {
    const t = $("toast"); t.textContent = msg; t.classList.remove("hidden");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.add("hidden"), 1800);
  }
  function ask({ message, input, ok = "OK", danger = false }) {
    return new Promise((resolve) => {
      $("dialog-msg").textContent = message;
      const inp = $("dialog-input");
      inp.classList.toggle("hidden", input === undefined);
      if (input !== undefined) inp.value = input;
      $("dialog-ok").textContent = ok;
      $("dialog-ok").classList.toggle("danger", danger);
      $("dialog").classList.remove("hidden");
      if (input !== undefined) setTimeout(() => { inp.focus(); inp.select(); }, 30);
      const done = (v) => {
        $("dialog").classList.add("hidden");
        $("dialog-ok").onclick = $("dialog-cancel").onclick = inp.onkeydown = null;
        resolve(v);
      };
      $("dialog-ok").onclick = () => done(input !== undefined ? inp.value : true);
      $("dialog-cancel").onclick = () => done(null);
      inp.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); done(inp.value); } };
    });
  }
  function showMenu(anchor, items) {
    const m = $("menu"); m.textContent = "";
    for (const it of items) {
      const b = document.createElement("button"); b.type = "button";
      const l = document.createElement("span"); l.className = "menu-label"; l.textContent = (it.checked ? "✓ " : "") + it.label; b.appendChild(l);
      if (it.sub) { const sp = document.createElement("span"); sp.className = "menu-sub"; sp.textContent = it.sub; b.appendChild(sp); }
      const cls = []; if (it.danger) cls.push("danger"); if (it.disabled) cls.push("disabled");
      b.className = cls.join(" ");
      if (it.disabled) b.setAttribute("aria-disabled", "true");
      b.onclick = () => { closeMenu(); if (it.disabled) toast(it.disabledMsg || NOT_CONF); else it.run(); };
      m.appendChild(b);
    }
    m.classList.remove("hidden");
    const r = anchor.getBoundingClientRect();
    const mw = m.offsetWidth, mh = m.offsetHeight;
    let left = Math.min(Math.max(8, r.right - mw), innerWidth - mw - 8);
    let top = r.bottom + 4; if (top + mh > innerHeight - 8) top = Math.max(8, r.top - mh - 4);
    m.style.left = left + "px"; m.style.top = top + "px";
    setTimeout(() => document.addEventListener("click", closeMenu, { once: true }), 0);
  }
  function closeMenu() { $("menu").classList.add("hidden"); }
  const setMsg = (id, text, bad) => { const e = $(id); e.textContent = text || ""; e.className = "small" + (bad ? " error" : ""); };

  // ------------------------------------------------------------------ views
  function hideAll() { for (const id of ["boot", "auth-view", "app", "settings-view", "admin-view"]) $(id).classList.add("hidden"); }
  function showAuth() { hideAll(); $("auth-view").classList.remove("hidden"); setAuthMode("login"); }
  function showApp() { hideAll(); $("app").classList.remove("hidden"); }
  const openNav = () => $("app").classList.add("nav-open");
  const closeNav = () => $("app").classList.remove("nav-open");

  // ------------------------------------------------------------------ sign in / invite
  let authMode = "login";
  function setAuthMode(m) {
    authMode = m;
    $("tab-login").classList.toggle("active", m === "login");
    $("tab-invite").classList.toggle("active", m === "invite");
    $("a-code-wrap").classList.toggle("hidden", m === "login");
    $("a-name-wrap").classList.toggle("hidden", m === "login");
    $("a-hint").classList.toggle("hidden", m === "login");
    $("a-pw-label").textContent = m === "login" ? "Password" : "Choose a password";
    $("a-pw").autocomplete = m === "login" ? "current-password" : "new-password";
    $("a-code").required = m === "invite";
    $("a-submit").textContent = m === "login" ? "Sign in" : "Create / reset my password";
    $("a-error").textContent = "";
  }
  $("tab-login").onclick = () => setAuthMode("login");
  $("tab-invite").onclick = () => setAuthMode("invite");
  $("auth-form").onsubmit = async (e) => {
    e.preventDefault(); $("a-error").textContent = ""; $("a-submit").disabled = true;
    try {
      const body = { email: $("a-email").value, password: $("a-pw").value };
      if (authMode === "invite") { body.code = $("a-code").value; body.name = $("a-name").value; }
      state.me = await api("POST", authMode === "login" ? "/api/login" : "/api/activate", body);
      $("a-pw").value = ""; $("a-code").value = "";
      await enterApp();
    } catch (err) { $("a-error").textContent = err.message; }
    $("a-submit").disabled = false;
  };

  // ------------------------------------------------------------------ app entry
  function pillInitial(name, email) { return ((name || email || "?").trim()[0] || "?").toUpperCase(); }
  async function refreshConfig() {
    cfg = await api("GET", "/api/config");
    state.features = cfg.features;
    if (!cfg.modes[state.mode]) state.mode = "default";
    if (!cfg.search.available) state.webSearch = false;
    if (state.compose && !(cfg[state.compose] && cfg[state.compose].available)) state.compose = null;
    const tiers = ["default", "fast", "reasoning"].filter((k) => cfg.modes[k]).length;
    const routable = !!(cfg.modes.smart && (cfg.search.available || cfg.image.available || cfg.video.available));
    $("model-btn").classList.toggle("hidden", tiers < 2 && !routable);
    renderModes();
  }
  async function enterApp() {
    await refreshConfig();
    applyTheme(state.me.prefs.theme || "system");
    $("acc-name").textContent = state.me.name || state.me.email;
    $("acc-email").textContent = state.me.email;
    $("avatar").textContent = pillInitial(state.me.name, state.me.email);
    const acc = [];
    if (state.features.pdf) acc.push(".pdf");
    acc.push(".docx", ".txt", ".md", ".csv", ".tsv", ".json", ".xml", ".html", ".css", ".js", ".ts", ".py", ".java", ".c", ".cpp", ".h", ".go", ".rs", ".sql", ".yaml", ".yml", ".log", ".sh", ".rb", ".php", ".tex", ".ini", ".toml");
    $("file-input").accept = acc.join(",");
    showApp();
    await loadConversations();
    let last = null; try { last = localStorage.getItem("aajao-last"); } catch { /* ignore */ }
    if (last && state.convs.some((c) => c.id === last)) { try { await openConversation(last, true); return; } catch { /* fall through */ } }
    newChat(true);
  }

  // ------------------------------------------------------------------ conversation list
  async function loadConversations() {
    const q = $("search").value.trim();
    state.convs = await api("GET", "/api/conversations" + (q ? "?q=" + encodeURIComponent(q) : ""));
    renderConvList(q);
  }
  function renderConvList(q) {
    const ul = $("conv-list"); ul.textContent = "";
    if (!state.convs.length) {
      const li = document.createElement("li"); li.className = "empty";
      li.textContent = q ? "No chats match your search." : "No chats yet. Say hello!"; ul.appendChild(li); return;
    }
    for (const c of state.convs) {
      const li = document.createElement("li"); if (c.id === state.currentId) li.className = "active";
      const t = document.createElement("div"); t.className = "conv-title"; t.textContent = c.title;
      t.onclick = () => openConversation(c.id);
      const more = document.createElement("button"); more.className = "conv-more"; more.textContent = "⋯"; more.setAttribute("aria-label", "Chat options");
      more.onclick = (ev) => { ev.stopPropagation(); showMenu(more, [
        { label: "Rename", run: () => renameConv(c) },
        { label: "Delete", danger: true, run: () => deleteConv(c) },
      ]); };
      li.append(t, more); ul.appendChild(li);
    }
  }
  let searchTimer;
  $("search").oninput = () => { clearTimeout(searchTimer); searchTimer = setTimeout(() => loadConversations().catch(() => {}), 250); };

  async function renameConv(c) {
    const v = await ask({ message: "Rename chat", input: c.title, ok: "Save" });
    if (v === null || !v.trim()) return;
    try { const r = await api("POST", `/api/conversations/${c.id}/rename`, { title: v }); if (c.id === state.currentId) setTitle(r.title); await loadConversations(); }
    catch (e) { toast(e.message); }
  }
  async function deleteConv(c) {
    const ok = await ask({ message: `Delete "${c.title}"? This cannot be undone.`, ok: "Delete", danger: true });
    if (!ok) return;
    try {
      await api("DELETE", "/api/conversations/" + c.id);
      if (c.id === state.currentId) newChat(true);
      await loadConversations();
    } catch (e) { toast(e.message); }
  }

  function setTitle(t) { $("chat-title").textContent = t || "New chat"; }
  function newChat(silent) {
    if (state.busy && state.controller) state.controller.abort();
    state.currentId = null; state.messages = []; state.pending = []; renderChips();
    try { localStorage.removeItem("aajao-last"); } catch { /* ignore */ }
    setTitle("New chat"); setError(""); renderMessages(); renderConvList($("search").value.trim());
    closeNav(); if (!silent) $("input").focus();
  }
  async function openConversation(id, silent) {
    if (state.busy && state.controller) state.controller.abort();
    const c = await api("GET", "/api/conversations/" + id);
    state.currentId = c.id; state.messages = c.messages; state.pending = []; renderChips();
    try { localStorage.setItem("aajao-last", c.id); } catch { /* ignore */ }
    setTitle(c.title); setError(""); state.stick = true; renderMessages(); renderConvList($("search").value.trim());
    closeNav(); startPolling();
  }
  $("new-chat").onclick = () => newChat();
  $("top-new").onclick = () => newChat();
  $("menu-btn").onclick = openNav;
  $("scrim").onclick = closeNav;

  // ------------------------------------------------------------------ message rendering
  const box = () => $("messages");
  box().addEventListener("scroll", () => { const b = box(); state.stick = b.scrollHeight - b.scrollTop - b.clientHeight < 80; }, { passive: true });
  function scrollDown(force) { const b = box(); if (force || state.stick) b.scrollTop = b.scrollHeight; }
  function setError(t) { $("chat-error").textContent = t || ""; }
  const lastIndex = () => state.messages.length - 1;

  function actBtn(label, fn) { const b = document.createElement("button"); b.type = "button"; b.className = "act"; b.textContent = label; b.onclick = fn; return b; }

  function messageEl(m, i) {
    const wrap = document.createElement("div"); wrap.className = "msg " + m.role;
    if (m.role === "user") {
      if (m.attachments && m.attachments.length) {
        const row = document.createElement("div"); row.className = "attach-row";
        for (const a of m.attachments) {
          if (a.kind === "image") { const im = document.createElement("img"); im.src = "/api/files/" + a.id; im.alt = a.name; im.loading = "lazy"; row.appendChild(im); }
          else { const p = document.createElement("span"); p.className = "file-pill"; p.textContent = "📎 " + a.name; row.appendChild(p); }
        }
        wrap.appendChild(row);
      }
      if (m.content) { const b = document.createElement("div"); b.className = "bubble"; b.textContent = m.content; wrap.appendChild(b); }
      const acts = document.createElement("div"); acts.className = "msg-actions";
      acts.appendChild(actBtn("Copy", async () => toast((await MD.copyText(m.content)) ? "Copied" : "Copy failed")));
      if (m.id) acts.appendChild(actBtn("Edit", () => startEdit(m, wrap)));
      wrap.appendChild(acts);
    } else {
      if (m.generation) {
        wrap.appendChild(genCard(m));
        return wrap;
      }
      const b = document.createElement("div"); b.className = "bubble md"; m._el = b;
      if (m.content) MD.render(m.content, b);
      else if (m.status === "streaming") {
        const c = document.createElement("span"); c.className = "typing"; b.appendChild(c);
        if (m.statusText) { const t = document.createElement("span"); t.className = "hint"; t.textContent = m.statusText; b.appendChild(t); }
      }
      wrap.appendChild(b);
      for (const n of [].concat(m.notices || [], m.notice ? [m.notice] : [])) {
        const nn = document.createElement("div"); nn.className = "note"; nn.textContent = n; wrap.appendChild(nn);
      }
      const srcs = (m.sources || []).filter((x) => x && /^https?:\/\//i.test(x.url || ""));
      if (m.model || srcs.length) {
        const meta = document.createElement("div"); meta.className = "meta";
        if (m.model) { const t = document.createElement("span"); t.textContent = m.model; meta.appendChild(t); }
        if (srcs.length) { const t = document.createElement("span"); t.className = "tag"; t.textContent = "Web-assisted"; meta.appendChild(t); }
        wrap.appendChild(meta);
      }
      if (srcs.length) {
        const box2 = document.createElement("div"); box2.className = "sources";
        const h = document.createElement("div"); h.textContent = "Sources"; box2.appendChild(h);
        const ol = document.createElement("ol");
        for (const x of srcs) {
          const li = document.createElement("li"); const a = document.createElement("a");
          a.href = x.url; a.target = "_blank"; a.rel = "noopener noreferrer"; a.textContent = x.title || x.url; li.appendChild(a); ol.appendChild(li);
        }
        box2.appendChild(ol); wrap.appendChild(box2);
      }
      if (m.status === "stopped" || m.status === "error") {
        const n = document.createElement("div"); n.className = "note" + (m.status === "error" ? " err" : "");
        n.textContent = m.status === "stopped" ? "Generation stopped." : "This reply was interrupted by an error.";
        wrap.appendChild(n);
      }
      if (m.status !== "streaming") {
        const acts = document.createElement("div"); acts.className = "msg-actions";
        acts.appendChild(actBtn("Copy", async () => toast((await MD.copyText(m.content)) ? "Copied" : "Copy failed")));
        if (i === lastIndex()) acts.appendChild(actBtn("Regenerate", regenerate));
        wrap.appendChild(acts);
      }
    }
    return wrap;
  }

  const SUGGEST = [
    ["Summarize", "Summarize this: "], ["Rewrite", "Rewrite this to sound clearer and more professional: "], ["Translate", "Translate this into English: "],
    ["Explain", "Explain this simply: "], ["Brainstorm", "Brainstorm ideas for: "], ["Write code", "Write code that "], ["Debug code", "Find the bug in this code:\n"],
    ["Study notes", "Make study notes on: "], ["Quiz me", "Quiz me on: "], ["Make a table", "Make a table comparing: "], ["Extract info", "Extract the key facts from this: "],
  ];
  function renderMessages() {
    const b = box(); b.textContent = "";
    if (!state.messages.length) {
      const w = document.createElement("div"); w.className = "welcome";
      w.innerHTML = ""; const logo = document.createElement("div"); logo.className = "logo"; logo.textContent = "aajao";
      const p = document.createElement("p"); p.className = "muted"; p.textContent = "How can I help today?";
      w.append(logo, p);
      const sg = document.createElement("div"); sg.className = "suggest";
      for (const [label, text] of SUGGEST) {
        const sb = document.createElement("button"); sb.type = "button"; sb.className = "btn"; sb.textContent = label;
        sb.onclick = () => { input.value = text; autoGrow(); input.focus(); };
        sg.appendChild(sb);
      }
      w.appendChild(sg); b.appendChild(w); return;
    }
    state.messages.forEach((m, i) => b.appendChild(messageEl(m, i)));
    const last = state.messages[lastIndex()];
    if (last && last.role === "user" && !state.busy) {
      const n = document.createElement("div"); n.className = "msg";
      const t = document.createElement("div"); t.className = "note err"; t.textContent = "No reply was received.";
      n.append(t, actBtn("Retry", regenerate)); b.appendChild(n);
    }
    scrollDown(true);
  }

  let rafPending = false;
  function scheduleRender(m) {
    if (rafPending) return; rafPending = true;
    requestAnimationFrame(() => { rafPending = false; if (m._el) { MD.render(m.content, m._el); scrollDown(); } });
  }

  function startEdit(m, wrap) {
    if (state.busy) return;
    wrap.textContent = "";
    const ebox = document.createElement("div"); ebox.className = "edit-box";
    const ta = document.createElement("textarea"); ta.value = m.content; ta.maxLength = 20000;
    const row = document.createElement("div"); row.className = "row end";
    const cancel = document.createElement("button"); cancel.className = "btn"; cancel.type = "button"; cancel.textContent = "Cancel"; cancel.onclick = renderMessages;
    const save = document.createElement("button"); save.className = "btn primary"; save.type = "button"; save.textContent = "Save & send";
    save.onclick = () => { const v = ta.value.trim(); if (v) sendMessage(v, { editId: m.id, keepAtt: true }); };
    row.append(cancel, save); ebox.append(ta, row); wrap.appendChild(ebox); ta.focus();
  }

  // ------------------------------------------------------------------ streaming
  async function readSSE(url, body, signal, onEvent) {
    const res = await fetch(url, {
      method: "POST", credentials: "same-origin", signal,
      headers: { "Content-Type": "application/json", "X-Requested-With": "aajao" },
      body: JSON.stringify(body || {}),
    });
    if (!res.ok) {
      if (res.status === 401 && state.me) { state.me = null; showAuth(); }
      let d = {}; try { d = await res.json(); } catch { /* ignore */ }
      const er = new Error(d.error || "Request failed"); er.preStream = true; er.needsConfirm = !!d.needs_confirm; throw er;
    }
    const reader = res.body.getReader(); const dec = new TextDecoder(); let buf = "";
    for (;;) {
      const { done, value } = await reader.read(); if (done) break;
      buf = (buf + dec.decode(value, { stream: true })).replace(/\r\n/g, "\n");
      let i;
      while ((i = buf.indexOf("\n\n")) >= 0) {
        const block = buf.slice(0, i); buf = buf.slice(i + 2);
        let ev = "message", data = "";
        for (const line of block.split("\n")) {
          if (line.startsWith("event:")) ev = line.slice(6).trim();
          else if (line.startsWith("data:")) data += line.slice(5).trim();
        }
        if (data) { try { onEvent(ev, JSON.parse(data)); } catch { /* ignore malformed */ } }
      }
    }
  }

  function setBusy(b) {
    state.busy = b;
    const s = $("send-btn"); s.textContent = b ? "■" : "➤"; s.classList.toggle("stop", b);
    s.setAttribute("aria-label", b ? "Stop generating" : "Send");
  }

  async function streamInto(url, body, a, onPreFail) {
    setBusy(true); setError("");
    let confirmReq = null, gotGen = false;
    const ctl = new AbortController(); state.controller = ctl;
    const convId = state.currentId;
    let aborted = false;
    try {
      await readSSE(url, body, ctl.signal, (ev, d) => {
        if (state.currentId !== convId) return;
        if (ev === "delta") { a.content += d.t; scheduleRender(a); }
        else if (ev === "meta") { if (d.model) a.model = d.model; }
        else if (ev === "status") { a.statusText = d.text || ""; if (!a.content) renderMessages(); }
        else if (ev === "notice") { (a.notices = a.notices || []).push(d.text); renderMessages(); }
        else if (ev === "sources") { a.sources = d.sources || []; }
        else if (ev === "generation") { gotGen = true; }
        else if (ev === "confirm") { confirmReq = d; }
        else if (ev === "error") { setError(d.message); }
        else if (ev === "done") { a.status = d.status; if (d.title) setTitle(d.title); setBusy(false); }
        else if (ev === "title") { setTitle(d.title); loadConversations().catch(() => {}); }
      });
    } catch (e) {
      if (e.name === "AbortError") aborted = true;
      else { setError(e.message || "Connection problem. Check your internet and retry."); if (e.preStream && onPreFail) onPreFail(e); }
    }
    setBusy(false); state.controller = null;
    if (state.currentId !== convId) return;
    if (aborted) await new Promise((r) => setTimeout(r, 500)); // let the server save the partial reply
    try {
      const c = await api("GET", "/api/conversations/" + convId);
      state.messages = c.messages; setTitle(c.title);
    } catch { /* keep local view */ }
    renderMessages();
    loadConversations().catch(() => {});
    try { localStorage.setItem("aajao-last", convId); } catch { /* ignore */ }
    startPolling();
    if (gotGen) refreshConfig().catch(() => {});
    if (confirmReq) startGeneration("video", confirmReq.prompt, { userMessageId: confirmReq.user_message_id });
  }

  async function sendMessage(text, opts = {}) {
    if (state.busy) return;
    const atts = opts.editId ? [] : state.pending.slice();
    if (!text.trim() && !atts.length) return;
    if (atts.some((a) => a.uploading)) return toast("Wait for the upload to finish");
    setError("");
    try {
      if (!state.currentId) {
        const c = await api("POST", "/api/conversations"); state.currentId = c.id;
      }
    } catch (e) { return setError(e.message); }
    if (opts.editId) {
      const idx = state.messages.findIndex((m) => m.id === opts.editId);
      if (idx >= 0) { state.messages[idx].content = text; state.messages.length = idx + 1; }
    } else {
      state.messages.push({ id: null, role: "user", content: text, status: "complete",
        attachments: atts.map((a) => ({ id: a.id, name: a.name, kind: a.kind })) });
    }
    state.pending = []; renderChips();
    const a = { id: null, role: "assistant", content: "", status: "streaming", attachments: [] };
    state.messages.push(a); state.stick = true; renderMessages();
    const restore = () => { if (!opts.editId) { input.value = text; autoGrow(); state.pending = atts; renderChips(); } };
    await streamInto(`/api/conversations/${state.currentId}/messages`,
      { content: text, attachment_ids: atts.map((x) => x.id), edit_message_id: opts.editId || null, mode: state.mode, web_search: state.webSearch }, a, restore);
  }

  async function regenerate() {
    if (state.busy || !state.currentId) return;
    if (state.messages.length && state.messages[lastIndex()].role === "assistant") state.messages.pop();
    const a = { id: null, role: "assistant", content: "", status: "streaming", attachments: [] };
    state.messages.push(a); state.stick = true; renderMessages();
    await streamInto(`/api/conversations/${state.currentId}/regenerate`, { mode: state.mode, web_search: state.webSearch }, a);
  }

  // ------------------------------------------------------------------ composer
  const input = $("input");
  function autoGrow() { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 160) + "px"; }
  input.addEventListener("input", autoGrow);
  input.addEventListener("focus", () => setTimeout(() => scrollDown(true), 250));
  function enterSends() {
    const p = state.me && state.me.prefs.enterToSend;
    return p === undefined ? !matchMedia("(pointer: coarse)").matches : !!p;
  }
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing && enterSends()) { e.preventDefault(); $("composer").requestSubmit(); }
  });
  $("composer").onsubmit = (e) => {
    e.preventDefault();
    if (state.busy) { if (state.controller) state.controller.abort(); return; }
    const t = input.value; if (!t.trim() && !state.pending.length) return;
    if (state.compose) {
      if (!t.trim()) return toast("Describe what to create");
      const kind = state.compose;
      const img = state.pending.find((p) => p.kind === "image" && !p.uploading);
      const useSrc = img && cfg[kind].imageInput ? img : null;
      if (state.pending.some((p) => p.uploading)) return toast("Wait for the upload to finish");
      input.value = ""; autoGrow();
      startGeneration(kind, t.trim(), { sourceId: useSrc ? useSrc.id : null, restore: () => { input.value = t; autoGrow(); } });
      return;
    }
    input.value = ""; autoGrow(); sendMessage(t.trim());
  };

  // attachments
  $("attach-btn").onclick = (ev) => {
    ev.stopPropagation();
    const vid = cfg.video || {}, im = cfg.image || {};
    const hasReason = !!cfg.modes.reasoning;
    showMenu($("attach-btn"), [
      { label: "Upload image", sub: state.features.images ? "Ask about a photo or screenshot" : NOT_CONF, disabled: !state.features.images, run: () => $("image-input").click() },
      { label: "Upload file", sub: "PDF, Word, text, CSV", run: () => $("file-input").click() },
      { label: "Generate image", sub: im.available ? `${im.left} left today` : NOT_CONF, disabled: !im.available, checked: state.compose === "image",
        run: () => { state.compose = state.compose === "image" ? null : "image"; renderModes(); input.focus(); } },
      { label: "Generate video", sub: vid.available ? `${vid.left} left today · asks before starting` : NOT_CONF, disabled: !vid.available, checked: state.compose === "video",
        run: () => { state.compose = state.compose === "video" ? null : "video"; renderModes(); input.focus(); } },
      { label: "Web search", sub: cfg.search.available ? "Answer with real sources" : NOT_CONF, disabled: !cfg.search.available, checked: state.webSearch,
        run: () => { state.webSearch = !state.webSearch; renderModes(); } },
      { label: "Reasoning mode", sub: hasReason ? "Slower, for hard problems" : NOT_CONF, disabled: !hasReason, checked: state.mode === "reasoning",
        run: () => { state.mode = state.mode === "reasoning" ? "default" : "reasoning"; renderModes(); } },
    ]);
  };
  $("model-btn").onclick = (ev) => {
    ev.stopPropagation();
    const items = ["default", "fast", "reasoning", "smart"].filter((k) => cfg.modes[k]).map((k) => ({
      label: MODE_NAMES[k], checked: state.mode === k,
      sub: k === "smart" ? "Picks the best configured service" : (cfg.modes[k].model || ""),
      run: () => { state.mode = k; renderModes(); },
    }));
    showMenu($("model-btn"), items);
  };
  function renderModes() {
    $("model-label").textContent = MODE_NAMES[state.mode] || "Default";
    const c = $("modes"); c.textContent = "";
    const add = (label, off) => {
      const d = document.createElement("div"); d.className = "chip mode";
      const s2 = document.createElement("span"); s2.textContent = label;
      const x = document.createElement("button"); x.type = "button"; x.textContent = "✕"; x.setAttribute("aria-label", "Turn off " + label); x.onclick = () => { off(); renderModes(); };
      d.append(s2, x); c.appendChild(d);
    };
    if (state.compose) add(state.compose === "image" ? "Generate image" : "Generate video", () => { state.compose = null; });
    if (state.mode !== "default") add(MODE_NAMES[state.mode] + " mode", () => { state.mode = "default"; });
    if (state.webSearch) add("Web search", () => { state.webSearch = false; });
    input.placeholder = state.compose ? `Describe the ${state.compose} to create` : "Message aajao";
  }
  async function uploadFiles(files) {
    for (const f of files) {
      if (state.pending.length >= 4) { toast("Up to 4 files per message"); break; }
      const chip = { name: f.name, uploading: true, kind: /^image\//.test(f.type) ? "image" : "file", local: /^image\//.test(f.type) ? URL.createObjectURL(f) : null };
      state.pending.push(chip); renderChips();
      try {
        const res = await fetch("/api/uploads?name=" + encodeURIComponent(f.name), {
          method: "POST", credentials: "same-origin", body: f,
          headers: { "Content-Type": f.type || "application/octet-stream", "X-Requested-With": "aajao" },
        });
        const d = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(d.error || "Upload failed");
        Object.assign(chip, d, { uploading: false });
      } catch (e) {
        state.pending = state.pending.filter((c) => c !== chip); toast(e.message);
      }
      renderChips();
    }
  }
  $("file-input").onchange = () => { const f = [...$("file-input").files]; $("file-input").value = ""; uploadFiles(f); };
  $("image-input").onchange = () => { const f = [...$("image-input").files]; $("image-input").value = ""; uploadFiles(f); };
  function renderChips() {
    const c = $("chips"); c.textContent = "";
    for (const a of state.pending) {
      const d = document.createElement("div"); d.className = "chip";
      if (a.kind === "image" && (a.local || a.id)) { const im = document.createElement("img"); im.src = a.id ? "/api/files/" + a.id : a.local; im.alt = ""; d.appendChild(im); }
      const s = document.createElement("span"); s.textContent = a.name;
      const st = document.createElement("span"); st.className = "kind"; st.textContent = a.uploading ? "Uploading…" : (a.kind === "image" ? "Image · ready" : "File · ready");
      const x = document.createElement("button"); x.type = "button"; x.textContent = "✕"; x.setAttribute("aria-label", "Remove attachment");
      x.onclick = () => { state.pending = state.pending.filter((p) => p !== a); renderChips(); };
      d.append(s, st, x); c.appendChild(d);
    }
  }


  // ------------------------------------------------------------------ image / video generation
  async function startGeneration(kind, prompt, opts = {}) {
    if (state.busy) return;
    const meta = cfg[kind] || {};
    if (!meta.available) return toast(NOT_CONF);
    if (meta.left === 0) return setError(`You have used all of today's ${kind} generations.`);
    if (kind === "video") {
      const parts = ["Create this video? It uses paid credits on the video service."];
      if (meta.costNote) parts.push(meta.costNote);
      parts.push(`You have ${meta.left} video${meta.left === 1 ? "" : "s"} left today` + (meta.monthlyLeft != null ? ` and ${meta.monthlyLeft} left this month.` : "."));
      const ok = await ask({ message: parts.join(" "), ok: "Create video" });
      if (!ok) { if (opts.restore) opts.restore(); return; }
    }
    setError("");
    try {
      if (!state.currentId) { const c = await api("POST", "/api/conversations"); state.currentId = c.id; }
      const body = { kind, prompt, confirm: kind === "video" ? true : undefined };
      if (opts.sourceId) body.source_attachment_id = opts.sourceId;
      if (opts.userMessageId) body.user_message_id = opts.userMessageId;
      await api("POST", `/api/conversations/${state.currentId}/generate`, body);
      state.pending = state.pending.filter((p) => p.id !== opts.sourceId); renderChips();
      const c = await api("GET", "/api/conversations/" + state.currentId);
      state.messages = c.messages; setTitle(c.title); state.stick = true; renderMessages();
      loadConversations().catch(() => {});
      try { localStorage.setItem("aajao-last", state.currentId); } catch { /* ignore */ }
      startPolling(); refreshConfig().catch(() => {});
    } catch (e) { setError(e.message); if (opts.restore) opts.restore(); }
  }

  let pollTimer = null;
  function activeGens() { return state.messages.filter((m) => m.generation && (m.generation.status === "queued" || m.generation.status === "processing")); }
  function startPolling() {
    if (pollTimer || !activeGens().length) return;
    pollTimer = setInterval(pollGens, 2500);
  }
  async function pollGens() {
    const list = activeGens();
    if (!list.length || !state.me) { clearInterval(pollTimer); pollTimer = null; return; }
    let changed = false;
    for (const m of list) {
      try {
        const g = await api("GET", "/api/generations/" + m.generation.id);
        if (g.status !== m.generation.status) { m.generation = g; changed = true; }
      } catch { /* keep polling */ }
    }
    if (changed) { renderMessages(); refreshConfig().catch(() => {}); }
    if (!activeGens().length) { clearInterval(pollTimer); pollTimer = null; }
  }

  function openLightbox(url, name) {
    $("lb-img").src = url; $("lb-img").alt = name || "";
    $("lb-dl").href = url + "?download=1"; $("lightbox").classList.remove("hidden");
  }
  const closeLightbox = () => { $("lightbox").classList.add("hidden"); $("lb-img").removeAttribute("src"); };
  $("lb-close").onclick = closeLightbox;

  function genCard(m) {
    const g = m.generation, isVideo = g.kind === "video";
    const card = document.createElement("div"); card.className = "gen"; card.dataset.gen = g.status;
    const head = document.createElement("div"); head.className = "gen-head";
    const t = document.createElement("span"); t.textContent = isVideo ? "Video" : "Image";
    const st = document.createElement("span"); st.className = "gen-status " + g.status;
    st.textContent = { queued: "Queued", processing: "Processing", completed: "Completed", failed: "Failed" }[g.status] || g.status;
    head.append(t, st); card.appendChild(head);
    const pr = document.createElement("div"); pr.className = "gen-prompt"; pr.textContent = g.prompt || m.content || ""; card.appendChild(pr);
    const acts = document.createElement("div"); acts.className = "msg-actions";
    if (g.status === "queued" || g.status === "processing") {
      const w = document.createElement("div"); w.className = "gen-wait";
      w.textContent = isVideo ? "Creating your video. This can take a few minutes. You can leave this page; it keeps running." : "Creating your image…";
      card.appendChild(w);
    } else if (g.status === "completed" && g.attachment) {
      const url = "/api/files/" + g.attachment.id;
      if (isVideo) {
        const v = document.createElement("video"); v.className = "gen-video"; v.controls = true; v.playsInline = true; v.preload = "metadata"; v.src = url; card.appendChild(v);
      } else {
        const im = document.createElement("img"); im.className = "gen-img"; im.src = url; im.alt = g.prompt || "Generated image"; im.loading = "lazy";
        im.onclick = () => openLightbox(url, g.prompt); card.appendChild(im);
      }
      const dl = document.createElement("a"); dl.className = "act"; dl.textContent = "Download"; dl.href = url + "?download=1"; dl.setAttribute("download", ""); acts.appendChild(dl);
    } else if (g.status === "failed") {
      const e = document.createElement("div"); e.className = "gen-err"; e.textContent = g.error || "This could not be created."; card.appendChild(e);
    }
    if (g.status === "completed" || g.status === "failed") {
      acts.appendChild(actBtn(g.status === "failed" ? "Try again" : "Generate again", () => startGeneration(g.kind, g.prompt)));
      if (g.status === "completed" && g.attachment && !isVideo && cfg.image.imageInput)
        acts.appendChild(actBtn("Variation", () => startGeneration("image", g.prompt, { sourceId: g.attachment.id })));
      if (g.status === "completed" && g.attachment && !isVideo && cfg.video.imageToVideo)
        acts.appendChild(actBtn("Animate", () => startGeneration("video", g.prompt, { sourceId: g.attachment.id })));
    }
    if (acts.childNodes.length) card.appendChild(acts);
    return card;
  }

  // ------------------------------------------------------------------ account menu, settings
  $("account-btn").onclick = (ev) => {
    ev.stopPropagation();
    const items = [{ label: "Settings", run: openSettings }];
    if (state.me.role === "owner") items.push({ label: "Owner panel", run: openAdmin });
    items.push({ label: "Sign out", danger: true, run: logout });
    showMenu($("account-btn"), items);
  };
  async function logout() {
    try { await api("POST", "/api/logout"); } catch { /* ignore */ }
    if (state.controller) state.controller.abort();
    Object.assign(state, { me: null, currentId: null, messages: [], pending: [], busy: false, mode: "default", webSearch: false, compose: null });
    try { localStorage.removeItem("aajao-last"); } catch { /* ignore */ }
    showAuth();
  }

  function openSettings() {
    closeNav();
    $("settings-view").classList.remove("hidden");
    $("set-name").value = state.me.name; $("set-email").textContent = state.me.email;
    $("pref-enter").checked = enterSends(); $("pref-instr").value = state.me.prefs.customInstructions || "";
    applyTheme(state.me.prefs.theme || "system");
    for (const id of ["pref-msg", "acct-msg"]) setMsg(id, "");
  }
  $("settings-close").onclick = () => $("settings-view").classList.add("hidden");
  $("settings-logout").onclick = () => { $("settings-view").classList.add("hidden"); logout(); };
  document.querySelectorAll("#theme-seg .seg-btn").forEach((b) => {
    b.onclick = async () => {
      applyTheme(b.dataset.theme);
      try { state.me.prefs = await api("POST", "/api/me/prefs", { theme: b.dataset.theme }); } catch (e) { toast(e.message); }
    };
  });
  $("pref-save").onclick = async () => {
    try {
      state.me.prefs = await api("POST", "/api/me/prefs", { enterToSend: $("pref-enter").checked, customInstructions: $("pref-instr").value });
      setMsg("pref-msg", "Saved.");
    } catch (e) { setMsg("pref-msg", e.message, true); }
  };
  $("name-save").onclick = async () => {
    try {
      const r = await api("POST", "/api/me/profile", { name: $("set-name").value });
      state.me.name = r.name; $("acc-name").textContent = r.name; $("avatar").textContent = pillInitial(r.name, state.me.email);
      setMsg("acct-msg", "Name saved.");
    } catch (e) { setMsg("acct-msg", e.message, true); }
  };
  $("pw-save").onclick = async () => {
    try {
      await api("POST", "/api/me/password", { current: $("pw-cur").value, next: $("pw-new").value });
      $("pw-cur").value = $("pw-new").value = ""; setMsg("acct-msg", "Password changed. Other devices were signed out.");
    } catch (e) { setMsg("acct-msg", e.message, true); }
  };

  // ------------------------------------------------------------------ owner panel
  async function openAdmin() { closeNav(); $("admin-view").classList.remove("hidden"); $("code-box").classList.add("hidden"); setMsg("inv-msg", ""); await loadAdmin(); }
  $("admin-close").onclick = () => $("admin-view").classList.add("hidden");

  async function loadAdmin() {
    let o;
    try { o = await api("GET", "/api/admin/overview"); } catch (e) { return toast(e.message); }
    state.shareUrl = o.shareUrl;
    $("share-url").value = o.shareUrl;
    $("share-note").textContent = o.https ? "" : "Not HTTPS. Open this panel from your deployed https:// address before sharing.";
    $("wa-link").href = "https://wa.me/?text=" + encodeURIComponent("You're invited to aajao: " + o.shareUrl);
    $("set-limit").value = o.settings.dailyLimit; $("set-prompt").value = o.settings.systemPrompt;

    const s = $("ai-status"); s.textContent = "";
    const BADGE = { not_configured: ["Not configured", ""], not_verified: ["Not verified", "warnb"], verified: ["Verified", "ok"], failed: ["Failed", "bad"] };
    const TEST = new Set(["text", "fast", "reasoning", "vision", "search"]);
    for (const c of o.capabilities) {
      const row = document.createElement("div"); row.className = "cap"; row.dataset.cap = c.id;
      const line = document.createElement("div"); line.className = "cap-line";
      const nm = document.createElement("span"); nm.textContent = c.label;
      const b = document.createElement("span"); const bd = BADGE[c.status] || [c.status, ""]; b.className = "badge " + bd[1]; b.textContent = bd[0];
      line.append(nm, b); row.appendChild(line);
      const add = (t, cls) => { const d = document.createElement("div"); d.className = "small " + (cls || "muted"); d.textContent = t; row.appendChild(d); };
      if (c.configured) add(`${c.provider || "?"} · ${c.model || "?"}${c.host ? " · " + c.host : ""}`);
      else add(c.reason || "Not configured");
      if (c.warning) add(c.warning, "warn");
      if (c.lastError) add(`Last error ${new Date(c.lastError.at).toLocaleString()}: ${c.lastError.message || ""}`, "error");
      if (c.costNote) add("Cost note: " + c.costNote);
      if (c.configured && c.status !== "verified" && !TEST.has(c.id)) add("Becomes verified after one real generation succeeds.");
      if (c.configured && TEST.has(c.id)) {
        const tb = document.createElement("button"); tb.type = "button"; tb.className = "btn sm"; tb.textContent = "Test";
        tb.onclick = async () => {
          tb.disabled = true; tb.textContent = "Testing…";
          try { const r = await api("POST", `/api/admin/capabilities/${c.id}/test`); toast(r.ok ? "Test passed: " + (r.detail || "OK") : "Test failed: " + r.error); }
          catch (e) { toast(e.message); }
          await loadAdmin();
        };
        row.appendChild(tb);
      }
      s.appendChild(row);
    }
    if (o.ai.lastError) { const d = document.createElement("div"); d.className = "small error"; d.textContent = `Last AI error: ${new Date(o.ai.lastError.at).toLocaleString()} · ${o.ai.lastError.kind} · HTTP ${o.ai.lastError.status} ${o.ai.lastError.detail}`; s.appendChild(d); }
    if (o.mediaLastError) { const d = document.createElement("div"); d.className = "small error"; d.textContent = "Last image/video error: " + JSON.stringify(o.mediaLastError).slice(0, 300); s.appendChild(d); }
    $("set-img-limit").value = o.settings.imageDailyLimit; $("set-vid-limit").value = o.settings.videoDailyLimit; $("set-vid-month").value = o.settings.videoMonthlyLimit;
    $("vid-month-used").textContent = `Videos created by everyone this month: ${o.settings.videoThisMonth}`;

    const u = $("users"); u.textContent = "";
    for (const x of o.users) u.appendChild(userCard(x));
  }

  function userCard(x) {
    const d = document.createElement("div"); d.className = "user-card";
    const l1 = document.createElement("div"); l1.className = "user-line";
    const em = document.createElement("span"); em.className = "user-email"; em.textContent = (x.name ? x.name + " · " : "") + x.email + (x.role === "owner" ? " (you)" : "");
    const bd = document.createElement("span"); bd.className = "badge " + (x.status === "active" ? "ok" : x.status === "disabled" ? "bad" : "");
    bd.textContent = x.status === "invited" ? "invited, not joined" : x.status;
    l1.append(em, bd);
    const l2 = document.createElement("div"); l2.className = "muted small";
    l2.textContent = `Chats ${x.chats} · Replies today ${x.requests_today} · Total ${x.requests_total} · Tokens ${x.input_tokens}/${x.output_tokens}` +
      (x.gen_images || x.gen_videos ? ` · Images ${x.gen_images} · Videos ${x.gen_videos}` : "") +
      (x.last_login_at ? ` · Last login ${new Date(x.last_login_at).toLocaleDateString()}` : "");
    d.append(l1, l2);
    if (x.role !== "owner") {
      const row = document.createElement("div"); row.className = "row";
      const add = (label, fn, cls) => { const b = document.createElement("button"); b.className = "btn sm " + (cls || ""); b.textContent = label; b.onclick = fn; row.appendChild(b); };
      const call = async (fn) => { try { await fn(); await loadAdmin(); } catch (e) { toast(e.message); } };
      if (x.status === "invited") {
        add("New invite code", () => call(async () => showCode(await api("POST", `/api/admin/users/${x.id}/code`), x)));
        add("Revoke invite", async () => { if (await ask({ message: `Revoke the invitation for ${x.email}?`, ok: "Revoke", danger: true })) call(() => api("DELETE", `/api/admin/users/${x.id}`)); }, "danger");
      } else if (x.status === "active") {
        add("Reset code", () => call(async () => showCode(await api("POST", `/api/admin/users/${x.id}/code`), x)));
        add("Disable", async () => { if (await ask({ message: `Disable ${x.email}? They are signed out immediately.`, ok: "Disable", danger: true })) call(() => api("POST", `/api/admin/users/${x.id}/disable`)); }, "danger");
        add("Remove", async () => { if (await ask({ message: `Permanently remove ${x.email} and ALL their chats?`, ok: "Remove", danger: true })) call(() => api("DELETE", `/api/admin/users/${x.id}`)); }, "danger");
      } else {
        add("Re-enable", () => call(() => api("POST", `/api/admin/users/${x.id}/enable`)));
        add("Remove", async () => { if (await ask({ message: `Permanently remove ${x.email} and ALL their chats?`, ok: "Remove", danger: true })) call(() => api("DELETE", `/api/admin/users/${x.id}`)); }, "danger");
      }
      d.appendChild(row);
    }
    return d;
  }

  function showCode(r, who) {
    const kind = r.kind || "invite";
    state.lastCode = {
      code: r.code,
      text: kind === "reset"
        ? `Password reset for aajao.\n1) Open: ${state.shareUrl}\n2) Tap "I have an invite code"\n3) Email: ${r.email}\n   Code: ${r.code}\n4) Choose a new password.\nThe code works once and expires in 7 days.`
        : `You're invited to aajao.\n1) Open: ${state.shareUrl}\n2) Tap "I have an invite code"\n3) Email: ${r.email}\n   Code: ${r.code}\n4) Choose your password.\nThe code works once and expires in 7 days.`,
    };
    $("code-val").textContent = r.code; $("code-box").classList.remove("hidden");
    $("code-box").scrollIntoView({ behavior: "smooth", block: "center" });
  }
  $("code-copy").onclick = async () => toast((await MD.copyText(state.lastCode.text)) ? "Invite message copied" : "Copy failed");
  $("copy-link").onclick = async () => {
    const ok = await MD.copyText($("share-url").value);
    $("copy-link").textContent = ok ? "Copied!" : "Copy failed";
    setTimeout(() => ($("copy-link").textContent = "Copy Share Link"), 1800);
  };
  $("invite-form").onsubmit = async (e) => {
    e.preventDefault(); setMsg("inv-msg", "");
    try {
      const r = await api("POST", "/api/admin/invite", { email: $("inv-email").value, name: $("inv-name").value });
      $("inv-email").value = ""; $("inv-name").value = "";
      showCode({ ...r, kind: "invite" }); setMsg("inv-msg", "Invitation created."); await loadAdmin();
    } catch (err) { setMsg("inv-msg", err.message, true); }
  };
  $("settings-save").onclick = async () => {
    try { await api("POST", "/api/admin/settings", { dailyLimit: Number($("set-limit").value), systemPrompt: $("set-prompt").value,
      imageDailyLimit: Number($("set-img-limit").value), videoDailyLimit: Number($("set-vid-limit").value), videoMonthlyLimit: Number($("set-vid-month").value) }); setMsg("settings-msg", "Saved."); }
    catch (e) { setMsg("settings-msg", e.message, true); }
  };

  // ------------------------------------------------------------------ boot
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") { closeMenu(); closeNav(); closeLightbox(); } });
  (async () => {
    try { state.me = await api("GET", "/api/me"); await enterApp(); }
    catch { state.me = null; showAuth(); }
  })();
})();
