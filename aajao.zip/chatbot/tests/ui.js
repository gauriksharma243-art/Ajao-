"use strict";
// Phone-size browser check. AI upstream is a MOCK (fixed Markdown reply). Takes screenshots into SHOTS_DIR.
const http = require("node:http");
const path = require("node:path");
const fs = require("node:fs");
const os = require("node:os");
const { spawn } = require("node:child_process");
const { chromium } = require(process.env.PLAYWRIGHT_PATH || "/opt/npm-tools/node_modules/playwright");

const SHOTS = process.env.SHOTS_DIR || fs.mkdtempSync(path.join(os.tmpdir(), "aajao-shots-"));
fs.mkdirSync(SHOTS, { recursive: true });
const REPLY = "## Plan\n\nHere is a **bold** point and `inline code`.\n\n- first item\n- second item\n  - nested item\n\n1. step one\n2. step two\n\n| Name | Value |\n|------|-------|\n| alpha | 1 |\n| beta | 2 |\n\n```js\nconst longLine = 'this line is intentionally long so that the code block must scroll sideways instead of the page';\nconsole.log(longLine);\n```\n\n<script>alert('xss')</script> [link](https://example.com)";
const results = [];
const check = (name, ok, extra = "") => { results.push({ name, ok }); console.log((ok ? "PASS " : "FAIL ") + name + (extra ? "  " + extra : "")); };

(async () => {
  const mock = http.createServer((req, res) => {
    let b = ""; req.on("data", (c) => (b += c)); req.on("end", async () => {
      const j = JSON.parse(b || "{}");
      res.writeHead(200, { "content-type": "text/event-stream" });
      const title = /short title/i.test(j.system || "");
      const text = title ? "Weekend plan" : REPLY;
      for (const w of text.split(/(?<=\s)/)) {
        res.write(`event: content_block_delta\ndata: ${JSON.stringify({ type: "content_block_delta", delta: { type: "text_delta", text: w } })}\n\n`);
        await new Promise((r) => setTimeout(r, 3));
      }
      res.end();
    });
  });
  await new Promise((r) => mock.listen(0, "127.0.0.1", r));
  const port = 4900 + Math.floor(Math.random() * 90);
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "aajao-ui-"));
  const srv = spawn(process.execPath, [path.join(__dirname, "..", "server.js")], {
    env: { ...process.env, PORT: String(port), DATA_DIR: dataDir, NODE_ENV: "test", OWNER_EMAIL: "owner@example.com", OWNER_PASSWORD: "owner-password-123",
      AI_PROVIDER: "anthropic", AI_API_KEY: "k", AI_MODEL: "m", AI_BASE_URL: `http://127.0.0.1:${mock.address().port}/v1` }, stdio: "ignore" });
  await new Promise((r) => setTimeout(r, 1200));
  const base = `http://127.0.0.1:${port}`;

  const browser = await chromium.launch({ args: ["--no-sandbox"] });
  const ctx = await browser.newContext({ viewport: { width: 360, height: 740 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true,
    userAgent: "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36", permissions: ["clipboard-read", "clipboard-write"] });
  const page = await ctx.newPage();
  const errors = []; page.on("pageerror", (e) => errors.push(e.message)); page.on("console", (m) => { if (m.type() === "error" && !/status of 401/.test(m.text())) errors.push(m.text()); }); // 401s are expected (signed-out check, deliberate wrong password)
  const noHScroll = async () => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1 && document.body.scrollWidth <= window.innerWidth + 1);
  const tapSize = async (sel) => page.evaluate((s) => { const r = document.querySelector(s).getBoundingClientRect(); return Math.min(r.width, r.height); }, sel);

  try {
    await page.goto(base);
    await page.waitForSelector("#auth-view:not(.hidden)");
    check("login page shows aajao, no horizontal scroll", (await page.textContent(".logo")) === "aajao" && await noHScroll());
    await page.screenshot({ path: path.join(SHOTS, "01-login.png") });
    await page.click("#tab-invite");
    check("invite tab shows code field", await page.isVisible("#a-code"));
    await page.screenshot({ path: path.join(SHOTS, "02-invite-tab.png") });
    await page.click("#tab-login");

    await page.fill("#a-email", "owner@example.com"); await page.fill("#a-pw", "wrong-password-1"); await page.tap("#a-submit");
    await page.waitForFunction(() => document.getElementById("a-error").textContent.length > 0);
    check("wrong password shows an error", true);
    await page.fill("#a-pw", "owner-password-123"); await page.tap("#a-submit");
    await page.waitForSelector("#app:not(.hidden)");
    check("owner signs in", true);
    check("composer visible and send button >= 44px", await page.isVisible("#input") && (await tapSize("#send-btn")) >= 44, `size=${await tapSize("#send-btn")}`);

    await page.fill("#input", "Plan my weekend"); await page.tap("#send-btn");
    await page.waitForSelector(".msg.assistant table", { timeout: 10000 });
    await page.waitForFunction(() => /Weekend plan/.test(document.getElementById("chat-title").textContent), null, { timeout: 8000 });
    check("streamed Markdown rendered: heading, list, table, code block", await page.evaluate(() => !!document.querySelector(".msg.assistant h2") && document.querySelectorAll(".msg.assistant li").length >= 5 && !!document.querySelector(".msg.assistant table") && !!document.querySelector(".msg.assistant .codeblock")));
    check("HTML in the reply is NOT executed (shown as text)", await page.evaluate(() => !document.querySelector(".msg.assistant script") && document.querySelector(".msg.assistant").textContent.includes("<script>")));
    check("no horizontal page scroll with wide code block", await noHScroll());
    check("AI-generated chat title applied", (await page.textContent("#chat-title")) === "Weekend plan");
    await page.screenshot({ path: path.join(SHOTS, "03-chat-light.png") });

    await page.tap(".codeblock .act");
    const clip = await page.evaluate(() => navigator.clipboard.readText());
    check("code copy button copies the code", clip.includes("const longLine"));
    await page.tap(".msg.assistant .msg-actions .act");
    check("message copy button works", (await page.evaluate(() => navigator.clipboard.readText())).includes("Plan"));
    check("Regenerate button on last reply", await page.isVisible("text=Regenerate"));
    check("Edit button on user message", await page.isVisible("text=Edit"));

    await page.tap("#menu-btn"); await page.waitForTimeout(350);
    check("history drawer opens on phone with the chat listed", await page.isVisible("#sidebar") && (await page.textContent("#conv-list")).includes("Weekend plan"));
    check("drawer rows are touch-sized", (await tapSize(".conv-title")) >= 44 || (await page.evaluate(() => document.querySelector("#conv-list li").getBoundingClientRect().height)) >= 44);
    await page.screenshot({ path: path.join(SHOTS, "04-drawer.png") });
    await page.fill("#search", "weekend"); await page.waitForTimeout(500);
    check("search finds the chat", (await page.locator("#conv-list li .conv-title").count()) === 1);
    await page.fill("#search", "zzzz-nothing"); await page.waitForTimeout(500);
    check("search with no match shows empty state", (await page.textContent("#conv-list")).includes("No chats match"));
    await page.fill("#search", "");
    await page.waitForTimeout(400);

    await page.tap("#account-btn"); await page.tap("#menu >> text=Settings");
    await page.waitForSelector("#settings-view:not(.hidden)");
    await page.tap("#theme-seg [data-theme=dark]"); await page.waitForTimeout(300);
    check("dark mode applies", await page.evaluate(() => document.documentElement.dataset.theme === "dark"));
    await page.screenshot({ path: path.join(SHOTS, "05-settings-dark.png") });
    check("settings page has no horizontal scroll", await noHScroll());
    await page.tap("#settings-close"); await page.waitForTimeout(200);
    await page.screenshot({ path: path.join(SHOTS, "06-chat-dark.png") });

    await page.tap("#menu-btn"); await page.tap("#account-btn"); await page.tap("#menu >> text=Owner panel");
    await page.waitForSelector("#admin-view:not(.hidden)");
    await page.waitForFunction(() => document.getElementById("share-url").value.startsWith("http"));
    await page.tap("#copy-link");
    check("Copy Share Link copies the main URL", (await page.evaluate(() => navigator.clipboard.readText())) === base);
    await page.fill("#inv-email", "friend@example.com"); await page.fill("#inv-name", "Friend"); await page.tap("#invite-form button");
    await page.waitForSelector("#code-box:not(.hidden)");
    const code = await page.textContent("#code-val");
    check("invite creates a one-time code", /^[A-Z0-9]{5}-[A-Z0-9]{5}$/.test(code));
    await page.tap("#code-copy");
    const invMsg = await page.evaluate(() => navigator.clipboard.readText());
    check("invite message contains link, email and code", invMsg.includes(base) && invMsg.includes("friend@example.com") && invMsg.includes(code));
    check("AI status shown to owner", (await page.textContent("#ai-status")).includes("anthropic"));
    check("owner panel has no horizontal scroll", await noHScroll());
    await page.screenshot({ path: path.join(SHOTS, "07-owner-panel.png"), fullPage: false });
    await page.tap("#admin-close");

    // invited user flow in a second, clean browser context
    const ctx2 = await browser.newContext({ viewport: { width: 360, height: 740 }, isMobile: true, hasTouch: true });
    const p2 = await ctx2.newPage(); await p2.goto(base); await p2.waitForSelector("#auth-view:not(.hidden)");
    await p2.tap("#tab-invite"); await p2.fill("#a-email", "friend@example.com"); await p2.fill("#a-code", code); await p2.fill("#a-pw", "friend-password-1"); await p2.tap("#a-submit");
    await p2.waitForSelector("#app:not(.hidden)");
    check("invited person activates with code and lands in chat", true);
    check("invited person has no Owner panel entry", await (async () => { await p2.tap("#menu-btn"); await p2.tap("#account-btn"); return !(await p2.locator("#menu >> text=Owner panel").count()); })());
    check("invited person sees none of the owner's chats", await p2.evaluate(() => !document.getElementById("conv-list").textContent.includes("Weekend plan")));
    await ctx2.close();

    await page.reload(); await page.waitForSelector("#app:not(.hidden)");
    await page.tap("#menu-btn"); await page.waitForTimeout(300);
    check("after reload: still signed in and history persists", (await page.textContent("#conv-list")).includes("Weekend plan"));
    check("no JavaScript errors in the console", errors.length === 0, errors.join(" | "));
  } catch (e) {
    check("UI run completed without exception", false, e.message);
    try { await page.screenshot({ path: path.join(SHOTS, "error.png") }); } catch { /* ignore */ }
  }
  await browser.close(); srv.kill("SIGTERM"); mock.close();
  const failed = results.filter((r) => !r.ok).length;
  console.log(`\n${results.length - failed}/${results.length} UI checks passed. Screenshots: ${SHOTS}`);
  process.exit(failed ? 1 : 0);
})();
