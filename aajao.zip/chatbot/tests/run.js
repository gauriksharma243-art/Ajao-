"use strict";
// Automated tests. The AI upstream here is a MOCK server (no real AI is contacted).
// What is exercised for real: the app's auth, database, ownership checks, uploads, and the
// provider code that formats requests and parses streaming responses.
// Run:  TEST_PROVIDER=anthropic node tests/run.js   and   TEST_PROVIDER=openai node tests/run.js
const test = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");
const path = require("node:path");
const fs = require("node:fs");
const os = require("node:os");
const { spawn } = require("node:child_process");

const PROVIDER = process.env.TEST_PROVIDER || "anthropic";
const OWNER = { email: "owner@example.com", password: "owner-password-123" };
const KEY = "test-key-SECRET-9876";
const PNG = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==", "base64");

let mock, mockPort, calls = [], server, base, dataDir;
const delay = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------- MOCK upstream (Anthropic + OpenAI-compatible, streaming) ----------------
function startMock() {
  return new Promise((resolve) => {
    mock = http.createServer((req, res) => {
      let body = "";
      req.on("data", (c) => (body += c));
      req.on("end", async () => {
        const j = JSON.parse(body || "{}");
        const auth = req.headers["x-api-key"] || req.headers["authorization"];
        calls.push({ url: req.url, auth, body: j });
        const isA = req.url.endsWith("/messages");
        const msgs = j.messages || [];
        const lastUser = msgs.filter((m) => m.role === "user").pop();
        const flat = (m) => typeof m.content === "string" ? m.content
          : (m.content || []).map((p) => p.text || "").join(" ");
        const text = lastUser ? flat(lastUser) : "";
        const sys = typeof j.system === "string" ? j.system : (msgs[0] && msgs[0].role === "system" ? msgs[0].content : "");
        if (text.includes("FAILNOW")) { res.writeHead(500, { "content-type": "application/json" }); return res.end('{"error":"boom"}'); }
        res.writeHead(200, { "content-type": "text/event-stream" });
        const isTitle = /short title/i.test(sys || j.system || "");
        const reply = isTitle ? "Mock Title" : text.includes("SLOW") ? Array.from({ length: 200 }, (_, i) => `w${i}`).join(" ")
          : "MOCK-REPLY: " + text.slice(0, 80);
        const words = reply.split(/(?<= )/);
        const slow = text.includes("SLOW");
        if (isA) res.write(`event: message_start\ndata: ${JSON.stringify({ type: "message_start", message: { usage: { input_tokens: 11 } } })}\n\n`);
        for (const w of words) {
          if (res.destroyed) return;
          res.write(isA
            ? `event: content_block_delta\ndata: ${JSON.stringify({ type: "content_block_delta", delta: { type: "text_delta", text: w } })}\n\n`
            : `data: ${JSON.stringify({ choices: [{ delta: { content: w } }] })}\n\n`);
          await delay(slow ? 40 : 2);
        }
        if (isA) { res.write(`event: message_delta\ndata: ${JSON.stringify({ type: "message_delta", usage: { output_tokens: 7 } })}\n\n`); }
        else { res.write(`data: ${JSON.stringify({ choices: [], usage: { prompt_tokens: 11, completion_tokens: 7 } })}\n\ndata: [DONE]\n\n`); }
        res.end();
      });
    });
    mock.listen(0, "127.0.0.1", () => { mockPort = mock.address().port; resolve(); });
  });
}

function startServer(port) {
  return new Promise((resolve, reject) => {
    const env = {
      ...process.env, PORT: String(port), DATA_DIR: dataDir, NODE_ENV: "test",
      OWNER_EMAIL: OWNER.email, OWNER_PASSWORD: OWNER.password,
      AI_PROVIDER: PROVIDER, AI_API_KEY: KEY, AI_MODEL: "test-model",
      AI_BASE_URL: `http://127.0.0.1:${mockPort}/v1`, DAILY_MESSAGE_LIMIT: "100", AI_SUPPORTS_IMAGES: "1",
    };
    server = spawn(process.execPath, [path.join(__dirname, "..", "server.js")], { env, stdio: ["ignore", "pipe", "pipe"] });
    let out = "";
    const onData = (d) => { out += d; if (out.includes("listening")) resolve(); };
    server.stdout.on("data", onData); server.stderr.on("data", (d) => (out += d));
    server.on("exit", (c) => reject(new Error("server exited " + c + "\n" + out)));
    setTimeout(() => reject(new Error("server start timeout\n" + out)), 8000);
  });
}
function stopServer() {
  return new Promise((resolve) => { server.removeAllListeners("exit"); server.on("exit", resolve); server.kill("SIGTERM"); });
}

// ---------------- tiny HTTP client with a cookie jar ----------------
function client() {
  let cookie = "";
  const c = {
    async req(method, url, body, extra = {}) {
      const headers = { "X-Requested-With": "aajao", ...(extra.headers || {}) };
      if (cookie) headers.Cookie = cookie;
      let payload;
      if (extra.raw !== undefined) payload = extra.raw;
      else if (body !== undefined) { headers["Content-Type"] = "application/json"; payload = JSON.stringify(body); }
      const res = await fetch(base + url, { method, headers, body: payload, redirect: "manual" });
      const sc = res.headers.get("set-cookie");
      if (sc) { const v = sc.split(";")[0]; cookie = v.endsWith("=") ? "" : v; }
      const ct = res.headers.get("content-type") || "";
      const data = ct.includes("json") ? await res.json() : null;
      return { status: res.status, data, res };
    },
    get: (u) => c.req("GET", u), post: (u, b) => c.req("POST", u, b), del: (u) => c.req("DELETE", u),
    async stream(url, body, { abortAfterDeltas } = {}) {
      const headers = { "X-Requested-With": "aajao", "Content-Type": "application/json" };
      if (cookie) headers.Cookie = cookie;
      const ctl = new AbortController();
      const res = await fetch(base + url, { method: "POST", headers, body: JSON.stringify(body || {}), signal: ctl.signal });
      if (!res.ok) return { status: res.status, data: await res.json(), events: [] };
      const events = []; const dec = new TextDecoder(); let buf = "", deltas = 0;
      try {
        for await (const chunk of res.body) {
          buf += dec.decode(chunk, { stream: true });
          let i;
          while ((i = buf.indexOf("\n\n")) >= 0) {
            const block = buf.slice(0, i); buf = buf.slice(i + 2);
            let ev = "message", data = "";
            for (const l of block.split("\n")) { if (l.startsWith("event:")) ev = l.slice(6).trim(); else if (l.startsWith("data:")) data += l.slice(5).trim(); }
            if (data) { events.push({ ev, d: JSON.parse(data) }); if (ev === "delta") deltas++; }
            if (abortAfterDeltas && deltas >= abortAfterDeltas) { ctl.abort(); throw Object.assign(new Error("aborted"), { name: "AbortError" }); }
          }
        }
      } catch (e) { if (e.name !== "AbortError") throw e; }
      return { status: 200, events, text: events.filter((e) => e.ev === "delta").map((e) => e.d.t).join("") };
    },
  };
  return c;
}

let owner, userA, userB, codeA, codeB;
const cleanup = () => { try { fs.rmSync(dataDir, { recursive: true, force: true }); } catch { /* ignore */ } };

test.before(async () => {
  dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "aajao-test-"));
  await startMock();
  const port = 4300 + Math.floor(Math.random() * 500);
  base = `http://127.0.0.1:${port}`;
  await startServer(port);
});
test.after(async () => { await stopServer().catch(() => {}); mock.close(); cleanup(); });

test(`[${PROVIDER}] unauthenticated access is refused everywhere`, async () => {
  const c = client();
  for (const [m, u] of [["GET", "/api/me"], ["GET", "/api/conversations"], ["POST", "/api/conversations"], ["GET", "/api/admin/overview"],
    ["POST", "/api/uploads"], ["GET", "/api/files/x"], ["GET", "/api/config"], ["POST", "/api/conversations/abc/messages"]]) {
    const r = await c.req(m, u, m === "POST" ? {} : undefined);
    assert.equal(r.status, 401, `${m} ${u}`);
  }
});

test(`[${PROVIDER}] CSRF: state-changing requests need the custom header and same origin`, async () => {
  const r1 = await fetch(base + "/api/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
  assert.equal(r1.status, 403);
  const r2 = await fetch(base + "/api/login", { method: "POST", headers: { "Content-Type": "application/json", "X-Requested-With": "aajao", Origin: "https://evil.example" }, body: "{}" });
  assert.equal(r2.status, 403);
});

test(`[${PROVIDER}] registration is disabled; login rejects bad credentials`, async () => {
  const c = client();
  assert.equal((await c.post("/api/signup", { email: "x@example.com", password: "password-12345" })).status, 404);
  assert.equal((await c.post("/api/register", { email: "x@example.com", password: "password-12345" })).status, 404);
  assert.equal((await c.post("/api/login", { email: "nobody@example.com", password: "password-12345" })).status, 401);
  assert.equal((await c.post("/api/activate", { email: "nobody@example.com", code: "AAAAA-BBBBB", password: "password-12345" })).status, 403);
});

test(`[${PROVIDER}] owner login, owner-only routes, logout`, async () => {
  owner = client();
  assert.equal((await owner.post("/api/login", { email: OWNER.email, password: "wrong-password-1" })).status, 401);
  const r = await owner.post("/api/login", OWNER);
  assert.equal(r.status, 200); assert.equal(r.data.role, "owner");
  const ov = await owner.get("/api/admin/overview");
  assert.equal(ov.status, 200);
  assert.equal(ov.data.ai.configured, true);
  assert.ok(ov.data.shareUrl.startsWith("http"));
  assert.ok(!JSON.stringify(ov.data).includes(KEY), "API key must never appear in admin data");
  const tmp = client(); await tmp.post("/api/login", OWNER);
  assert.equal((await tmp.post("/api/logout")).status, 200);
  assert.equal((await tmp.get("/api/me")).status, 401, "session is gone after logout");
});

test(`[${PROVIDER}] invitation flow: code required, single use, wrong code refused`, async () => {
  const inv = await owner.post("/api/admin/invite", { email: "A@Example.com", name: "Alice" });
  assert.equal(inv.status, 200); codeA = inv.data.code;
  assert.match(codeA, /^[A-Z0-9]{5}-[A-Z0-9]{5}$/);
  assert.equal((await owner.post("/api/admin/invite", { email: "a@example.com" })).status, 409, "duplicate invite");
  const inv2 = await owner.post("/api/admin/invite", { email: "b@example.com", name: "Bob" }); codeB = inv2.data.code;

  userA = client();
  assert.equal((await userA.post("/api/login", { email: "a@example.com", password: "password-12345" })).status, 401, "cannot log in before activation");
  assert.equal((await userA.post("/api/activate", { email: "a@example.com", code: "ZZZZZ-ZZZZZ", password: "password-12345" })).status, 403, "wrong code");
  assert.equal((await userA.post("/api/activate", { email: "a@example.com", code: codeA, password: "short" })).status, 400, "short password");
  const ok = await userA.post("/api/activate", { email: "a@example.com", code: codeA, password: "password-12345" });
  assert.equal(ok.status, 200); assert.equal(ok.data.name, "Alice");
  assert.equal((await client().post("/api/activate", { email: "a@example.com", code: codeA, password: "other-password-1" })).status, 403, "code is single use");

  userB = client();
  assert.equal((await userB.post("/api/activate", { email: "b@example.com", code: codeA, password: "password-67890" })).status, 403, "A's code does not work for B");
  assert.equal((await userB.post("/api/activate", { email: "b@example.com", code: codeB, password: "password-67890" })).status, 200);
});

test(`[${PROVIDER}] normal users cannot reach owner functions`, async () => {
  for (const [m, u, b] of [["GET", "/api/admin/overview"], ["POST", "/api/admin/invite", { email: "z@example.com" }],
    ["POST", "/api/admin/users/1/disable"], ["DELETE", "/api/admin/users/1"], ["POST", "/api/admin/settings", { dailyLimit: 5, systemPrompt: "x" }]]) {
    assert.equal((await userA.req(m, u, b)).status, 403, `${m} ${u}`);
  }
});

let convA;
test(`[${PROVIDER}] real streaming chat: deltas arrive, reply and title are saved`, async () => {
  convA = (await userA.post("/api/conversations")).data.id;
  calls.length = 0;
  const r = await userA.stream(`/api/conversations/${convA}/messages`, { content: "hello secret-from-A" });
  assert.equal(r.status, 200);
  assert.ok(r.events.filter((e) => e.ev === "delta").length > 2, "multiple streamed chunks");
  assert.match(r.text, /MOCK-REPLY: hello secret-from-A/);
  const done = r.events.find((e) => e.ev === "done"); assert.equal(done.d.status, "complete");
  assert.ok(r.events.some((e) => e.ev === "title" && e.d.title === "Mock Title"), "AI-generated title");
  const first = calls[0];
  assert.ok(first.auth.includes(KEY), "API key is sent to the provider from the server");
  const conv = (await userA.get(`/api/conversations/${convA}`)).data;
  assert.equal(conv.title, "Mock Title");
  assert.deepEqual(conv.messages.map((m) => m.role), ["user", "assistant"]);
});

test(`[${PROVIDER}] conversation memory: earlier messages are sent to the model`, async () => {
  calls.length = 0;
  await userA.stream(`/api/conversations/${convA}/messages`, { content: "second question" });
  const chat = calls.find((c) => !/short title/i.test(JSON.stringify(c.body.system || c.body.messages[0])));
  const roles = chat.body.messages.filter((m) => m.role !== "system").map((m) => m.role);
  assert.deepEqual(roles, ["user", "assistant", "user"]);
});

test(`[${PROVIDER}] user isolation: B cannot see, read, write, rename, delete or search A's chat`, async () => {
  assert.equal((await userB.get(`/api/conversations/${convA}`)).status, 404);
  assert.equal((await userB.post(`/api/conversations/${convA}/rename`, { title: "hacked" })).status, 404);
  assert.equal((await userB.del(`/api/conversations/${convA}`)).status, 404);
  assert.equal((await userB.post(`/api/conversations/${convA}/messages`, { content: "x" })).status, 404);
  assert.equal((await userB.post(`/api/conversations/${convA}/regenerate`, {})).status, 404);
  assert.deepEqual((await userB.get("/api/conversations")).data, []);
  assert.deepEqual((await userB.get("/api/conversations?q=secret-from-A")).data, [], "search is scoped to the user");
  assert.equal((await owner.get(`/api/conversations/${convA}`)).status, 404, "owner cannot read user chats");
  assert.equal((await userA.get("/api/conversations?q=secret-from-A")).data.length, 1, "A finds own chat by message text");
});

test(`[${PROVIDER}] rename, search by title, delete`, async () => {
  const c2 = (await userA.post("/api/conversations")).data.id;
  assert.equal((await userA.post(`/api/conversations/${c2}/rename`, { title: "Holiday plans" })).status, 200);
  assert.equal((await userA.get("/api/conversations?q=holiday")).data[0].id, c2);
  assert.equal((await userA.post(`/api/conversations/${c2}/rename`, { title: "  " })).status, 400);
  assert.equal((await userA.del(`/api/conversations/${c2}`)).status, 200);
  assert.equal((await userA.get(`/api/conversations/${c2}`)).status, 404);
});

test(`[${PROVIDER}] regenerate replaces the last reply; edit rewrites history from that point`, async () => {
  const c = (await userA.post("/api/conversations")).data.id;
  await userA.stream(`/api/conversations/${c}/messages`, { content: "one" });
  await userA.stream(`/api/conversations/${c}/messages`, { content: "two" });
  const before = (await userA.get(`/api/conversations/${c}`)).data.messages;
  assert.equal(before.length, 4);
  const rg = await userA.stream(`/api/conversations/${c}/regenerate`, {});
  assert.match(rg.text, /MOCK-REPLY: two/);
  const after = (await userA.get(`/api/conversations/${c}`)).data.messages;
  assert.equal(after.length, 4); assert.notEqual(after[3].id, before[3].id);
  const firstUser = after[0];
  const ed = await userA.stream(`/api/conversations/${c}/messages`, { content: "one-edited", edit_message_id: firstUser.id });
  assert.match(ed.text, /MOCK-REPLY: one-edited/);
  const msgs = (await userA.get(`/api/conversations/${c}`)).data.messages;
  assert.deepEqual(msgs.map((m) => m.role), ["user", "assistant"]);
  assert.equal(msgs[0].content, "one-edited");
});

test(`[${PROVIDER}] stop generation keeps the partial reply (status: stopped)`, async () => {
  const c = (await userA.post("/api/conversations")).data.id;
  const r = await userA.stream(`/api/conversations/${c}/messages`, { content: "SLOW please" }, { abortAfterDeltas: 5 });
  assert.ok(r.text.length > 0);
  await delay(800);
  const msgs = (await userA.get(`/api/conversations/${c}`)).data.messages;
  const a = msgs.find((m) => m.role === "assistant");
  assert.ok(a, "partial reply saved"); assert.equal(a.status, "stopped"); assert.ok(a.content.length > 0);
});

test(`[${PROVIDER}] provider failure: friendly error, user message kept, retry works`, async () => {
  const c = (await userA.post("/api/conversations")).data.id;
  const r = await userA.stream(`/api/conversations/${c}/messages`, { content: "FAILNOW" });
  const err = r.events.find((e) => e.ev === "error");
  assert.ok(err && !/boom|500/.test(err.d.message), "friendly message without internals");
  let msgs = (await userA.get(`/api/conversations/${c}`)).data.messages;
  assert.deepEqual(msgs.map((m) => m.role), ["user"]);
  const ov = (await owner.get("/api/admin/overview")).data;
  assert.ok(ov.ai.lastError && ov.ai.lastError.status === 500, "owner can see last AI error");
  // edit the failing text to something OK, then retry via regenerate
  const ed = await userA.stream(`/api/conversations/${c}/messages`, { content: "now fine", edit_message_id: msgs[0].id });
  assert.match(ed.text, /MOCK-REPLY: now fine/);
  const rg = await userA.stream(`/api/conversations/${c}/regenerate`, {});
  assert.match(rg.text, /MOCK-REPLY/);
});

test(`[${PROVIDER}] uploads: image and text are forwarded correctly; type/size/ownership validated`, async () => {
  const up = await userA.req("POST", "/api/uploads?name=pic.png", undefined, { raw: PNG, headers: { "Content-Type": "image/png" } });
  assert.equal(up.status, 200); assert.equal(up.data.kind, "image");
  const txt = await userA.req("POST", "/api/uploads?name=notes.txt", undefined, { raw: Buffer.from("alpha beta\nFILE-CONTENT-123"), headers: { "Content-Type": "text/plain" } });
  assert.equal(txt.status, 200); assert.equal(txt.data.kind, "text");
  assert.equal((await userA.req("POST", "/api/uploads?name=evil.exe", undefined, { raw: Buffer.from("MZ\x90\x00binary"), headers: { "Content-Type": "application/octet-stream" } })).status, 415);
  assert.equal((await userA.req("POST", "/api/uploads?name=fake.png", undefined, { raw: Buffer.from("not really a png"), headers: { "Content-Type": "image/png" } })).status, 415, "content is checked, not the name");
  assert.equal((await userA.req("POST", "/api/uploads?name=big.txt", undefined, { raw: Buffer.alloc(600 * 1024, 65), headers: { "Content-Type": "text/plain" } })).status, 413);
  const svg = await userA.req("POST", "/api/uploads?name=x.svg", undefined, { raw: Buffer.from("<svg onload=alert(1)/>"), headers: { "Content-Type": "image/svg+xml" } });
  assert.equal(svg.status, 415, "SVG is not accepted");

  const pdf = await userA.req("POST", "/api/uploads?name=d.pdf", undefined, { raw: Buffer.from("%PDF-1.4\n%fake"), headers: { "Content-Type": "application/pdf" } });
  if (PROVIDER === "anthropic") assert.equal(pdf.status, 200); else assert.equal(pdf.status, 400, "PDF refused where the provider cannot read PDFs");

  const c = (await userA.post("/api/conversations")).data.id;
  calls.length = 0;
  await userA.stream(`/api/conversations/${c}/messages`, { content: "what is this", attachment_ids: [up.data.id, txt.data.id] });
  const chat = calls.find((x) => !/short title/i.test(JSON.stringify(x.body.system || x.body.messages[0])));
  const lastUser = chat.body.messages.filter((m) => m.role === "user").pop();
  const parts = lastUser.content;
  if (PROVIDER === "anthropic") {
    assert.ok(parts.some((p) => p.type === "image" && p.source.media_type === "image/png" && p.source.data.length > 10), "anthropic image block");
    assert.ok(parts.some((p) => p.type === "text" && p.text.includes("FILE-CONTENT-123")), "text file inlined");
  } else {
    assert.ok(parts.some((p) => p.type === "image_url" && p.image_url.url.startsWith("data:image/png;base64,")), "openai image_url part");
    assert.ok(parts.some((p) => p.type === "text" && p.text.includes("FILE-CONTENT-123")), "text file inlined");
  }
  // files are private: only the owner of the file can fetch them
  assert.equal((await userA.get("/api/files/" + up.data.id)).status, 200);
  assert.equal((await userB.get("/api/files/" + up.data.id)).status, 404);
  assert.equal((await client().get("/api/files/" + up.data.id)).status, 401);
  // another user cannot attach A's upload
  const cb = (await userB.post("/api/conversations")).data.id;
  const steal = await userB.stream(`/api/conversations/${cb}/messages`, { content: "x", attachment_ids: [up.data.id] });
  assert.equal(steal.status, 400);
});

test(`[${PROVIDER}] context management: stored history is complete, sent context is bounded`, async () => {
  await stopServer();
  const port = Number(new URL(base).port);
  process.env.CONTEXT_CHAR_BUDGET = "3000";
  await startServer(port); delete process.env.CONTEXT_CHAR_BUDGET;
  const c = (await userA.post("/api/conversations")).data.id;
  // re-login after restart: also proves sessions and data survive a server restart
  assert.equal((await userA.get("/api/me")).status, 200, "session survives restart");
  for (let i = 0; i < 6; i++) await userA.stream(`/api/conversations/${c}/messages`, { content: `msg${i} ` + "x".repeat(900) });
  calls.length = 0;
  await userA.stream(`/api/conversations/${c}/messages`, { content: "latest " + "y".repeat(900) });
  const chat = calls.find((x) => !/short title/i.test(JSON.stringify(x.body.system || x.body.messages[0])));
  const sent = chat.body.messages.filter((m) => m.role !== "system").length;
  const stored = (await userA.get(`/api/conversations/${c}`)).data.messages.length;
  assert.equal(stored, 14, "all 14 messages stored");
  assert.ok(sent < stored, `only a window is sent (${sent} of ${stored})`);
  const last = chat.body.messages.filter((m) => m.role === "user").pop();
  assert.ok(JSON.stringify(last).includes("latest"), "newest message always included");
});

test(`[${PROVIDER}] permanent history: data survives restart and logout/login`, async () => {
  const before = (await userA.get("/api/conversations")).data;
  assert.ok(before.length >= 3);
  await stopServer();
  await startServer(Number(new URL(base).port));
  const fresh = client();
  assert.equal((await fresh.post("/api/login", { email: "a@example.com", password: "password-12345" })).status, 200);
  const after = (await fresh.get("/api/conversations")).data;
  assert.deepEqual(after.map((c) => c.id).sort(), before.map((c) => c.id).sort());
  const conv = (await fresh.get(`/api/conversations/${convA}`)).data;
  assert.ok(conv.messages.some((m) => m.content.includes("secret-from-A")));
  await fresh.post("/api/logout");
  const again = client(); await again.post("/api/login", { email: "a@example.com", password: "password-12345" });
  assert.equal((await again.get("/api/conversations")).data.length, before.length, "logout deletes nothing");
});

test(`[${PROVIDER}] password change and owner reset code`, async () => {
  const u = client(); await u.post("/api/login", { email: "b@example.com", password: "password-67890" });
  assert.equal((await u.post("/api/me/password", { current: "wrong", next: "new-password-123" })).status, 403);
  assert.equal((await u.post("/api/me/password", { current: "password-67890", next: "new-password-123" })).status, 200);
  assert.equal((await userB.get("/api/me")).status, 401, "other sessions signed out after password change");
  assert.equal((await client().post("/api/login", { email: "b@example.com", password: "new-password-123" })).status, 200);
  const uid = (await owner.get("/api/admin/overview")).data.users.find((x) => x.email === "b@example.com").id;
  const reset = await owner.post(`/api/admin/users/${uid}/code`);
  assert.equal(reset.data.kind, "reset");
  const rs = client();
  assert.equal((await rs.post("/api/activate", { email: "b@example.com", code: reset.data.code, password: "reset-password-123" })).status, 200);
  assert.equal((await client().post("/api/login", { email: "b@example.com", password: "reset-password-123" })).status, 200);
  userB = rs;
});

test(`[${PROVIDER}] owner can disable (instant lockout), re-enable, and remove users`, async () => {
  const ov = (await owner.get("/api/admin/overview")).data;
  const idA = ov.users.find((x) => x.email === "a@example.com").id;
  assert.equal((await owner.post(`/api/admin/users/${idA}/disable`)).status, 200);
  assert.equal((await userA.get("/api/me")).status, 401, "existing session dies immediately");
  assert.equal((await userA.get("/api/conversations")).status, 401);
  assert.equal((await client().post("/api/login", { email: "a@example.com", password: "password-12345" })).status, 401, "cannot log in while disabled");
  assert.equal((await owner.post(`/api/admin/users/${idA}/enable`)).status, 200);
  const back = client();
  assert.equal((await back.post("/api/login", { email: "a@example.com", password: "password-12345" })).status, 200);
  assert.ok((await back.get("/api/conversations")).data.length >= 3, "chats are still there after re-enable");
  const idOwner = ov.users.find((x) => x.role === "owner").id;
  assert.equal((await owner.post(`/api/admin/users/${idOwner}/disable`)).status, 400, "owner cannot be disabled");
  assert.equal((await owner.del(`/api/admin/users/${idOwner}`)).status, 400, "owner cannot be removed");
  const idB = ov.users.find((x) => x.email === "b@example.com").id;
  assert.equal((await owner.del(`/api/admin/users/${idB}`)).status, 200);
  assert.equal((await userB.get("/api/me")).status, 401);
  assert.ok(!(await owner.get("/api/admin/overview")).data.users.some((x) => x.email === "b@example.com"));
});

test(`[${PROVIDER}] usage stats, daily limit and settings`, async () => {
  const ov = (await owner.get("/api/admin/overview")).data;
  const a = ov.users.find((x) => x.email === "a@example.com");
  assert.ok(a.requests_total > 5 && a.input_tokens > 0 && a.output_tokens > 0, "usage recorded");
  assert.equal((await owner.post("/api/admin/settings", { dailyLimit: 0, systemPrompt: "x" })).status, 400);
  assert.equal((await owner.post("/api/admin/settings", { dailyLimit: 3, systemPrompt: "Be brief." })).status, 200);
  const a2 = client(); await a2.post("/api/login", { email: "a@example.com", password: "password-12345" });
  const c = (await a2.post("/api/conversations")).data.id;
  let limited = false;
  for (let i = 0; i < 40 && !limited; i++) { const r = await a2.stream(`/api/conversations/${c}/messages`, { content: "hi " + i }); if (r.status === 429) limited = true; }
  assert.ok(limited, "daily limit enforced for normal users");
  await owner.post("/api/admin/settings", { dailyLimit: 100, systemPrompt: "Be brief." });
});

test(`[${PROVIDER}] security headers, no secrets or source served, static traversal blocked`, async () => {
  const r = await fetch(base + "/");
  assert.equal(r.status, 200);
  assert.match(r.headers.get("content-security-policy"), /script-src 'self'/);
  assert.equal(r.headers.get("x-frame-options"), "DENY");
  const html = await r.text(); assert.ok(html.includes("aajao"));
  for (const p of ["/server.js", "/lib/db.js", "/package.json", "/../server.js", "/%2e%2e/server.js", "/data/aajao.db"]) {
    const x = await fetch(base + p); assert.equal(x.status, 404, p);
  }
  for (const p of ["/app.js", "/md.js", "/style.css", "/index.html"]) {
    const t = await (await fetch(base + p)).text(); assert.ok(!t.includes(KEY), p + " must not contain secrets");
  }
  const sc = await fetch(base + "/api/login", { method: "POST", headers: { "Content-Type": "application/json", "X-Requested-With": "aajao" }, body: JSON.stringify(OWNER) });
  const cookie = sc.headers.get("set-cookie"); assert.match(cookie, /HttpOnly/); assert.match(cookie, /SameSite=Lax/);
  const db = fs.readFileSync(path.join(dataDir, "aajao.db")).toString("latin1");
  assert.ok(!db.includes(OWNER.password) && !db.includes("password-12345"), "passwords are not stored in plain text");
});

test(`[${PROVIDER}] login rate limiting`, async () => {
  const c = client(); let limited = false;
  for (let i = 0; i < 12 && !limited; i++) { const r = await c.post("/api/login", { email: "ratelimit@example.com", password: "wrongwrongwrong" }); if (r.status === 429) limited = true; }
  assert.ok(limited);
});
